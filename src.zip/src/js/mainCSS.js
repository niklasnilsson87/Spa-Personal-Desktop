const mainCSS = document.createElement('template')
mainCSS.innerHTML = /* html */`
<style>
#container {
  width: auto;
  height: auto;
  background-color: white;
  position: absolute;
  border: 5px solid;
  border-color: lightblue;
  border-radius: 22px;
  z-index: 0;
}

#border-top {
  width: auto;
  height: 20px;
  border-bottom: solid;
  border-color: orange;
  background-color: lightblue;
  border-top-left-radius: 16px;
  border-top-right-radius: 16px;
}

h1 {
  font-family: "Segoe print", Arial, Helvetica, sans-serif;
  cursor: default;
  margin: 0 auto;
  text-align: center;
  margin-bottom: 30px;
}

#memoryContainer {
  background-image: linear-gradient(to bottom right, lightblue, rgb(0, 183, 255));
  padding: 30px;
  margin: 0 auto;
  width: 300px;
  height: 420px;
  border-bottom-left-radius: 16px;
  border-bottom-right-radius: 16px;
  }

.memory img {
  width: 25%;
  }

.memory .remove {
  visibility: hidden;
}

.win {
  margin-top: 10px;
  font-size: 20px
}

.time {
  margin-left: 125px;
  font-size: 27px;
}

p {
  margin: 0;
  padding: 0;
  text-align: center;
  font-family: helvetica;
  cursor: default;
}

.submit {
  display: inline-block;
  padding: 15px 25px;
  font-size: 18px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #00FF7F;
  border: none;
  border-radius: 45px;
  box-shadow: 0 3px #999;
}

.submit:hover {
  background-color: #add8e6
}

.submit:active {
  background-color: #3e8e41;
  box-shadow: 0 2px #666;
  transform: translateY(4px);
}

.weather_p {
  margin-left: 120px;
  float: left;
  font-family: helvetica;
}

#border-top #app-icon {
  float: left;
  margin-left: 10px;
}

#border-top img {
  float: right;
  width: 15px;
  margin-right: 6px;
  margin-top: 3px;
}

#weather {
  border-bottom-left-radius: 16px;
  border-bottom-right-radius: 16px;
  padding: 10px;
  background-image: linear-gradient(to bottom right, lightblue, rgb(0, 183, 255));
}

#disp {
  padding: 20px;
  font-size: 40px;
  display: flex;
  align-items: center;
  margin: 20px 25px 0px;
  border-radius: 16px;
  background-image: linear-gradient(to bottom right, white, lightblue);
}

#dispCity {
  font-size: 40px;
  flex: 1;
}

#cont1 {
  padding: 20px 0px 0px 30px;
}

.condition {
  font-family: cursive;
  font-size: 16px;
  text-align: right;
}

.weather_img {
  width: 70px;
  vertical-align: middle;
}

.city {
  margin-left: 60px;
  margin-top: 10px;
  margin-right: 20px;
  font-size: 18px;
  border: none;
  border-bottom: 1px solid black;
  background: none;
  transition: .5s ease;
}

.city:focus {
  box-shadow: none;
  border-bottom: 2px solid #222;
  outline: none;
  transition: 0.4s ease-in-out;
}

.chatApp {
  background-image: linear-gradient(to bottom right, lightblue, rgb(0, 183, 255));
  width: 460px;
  height: 480px;
  border-bottom-left-radius: 16px;
  border-bottom-right-radius: 16px;
}

#start_chat_button {
  margin-top: 30px;
}

.messages {
  margin-left: 20px;
  border-bottom: 1px solid;
  display: block;
  height: 330px;
  overflow: auto;
  overflow-x: hidden;
}

.message {
  display: table;
  margin-bottom: 15px;
}

.messageArea {
  outline: none;
  border-radius: 10px;
  position: absolute;
  bottom: 2px;
  left: 30px;
  width: 400px;
  height: 50px;
}

.text {
  text-align: left;
  float: left;
  font-family: sans-serif;
  margin: 0px;
  padding: 10px;
}

.autor {
  float: left;
  background-color: lightgray;
  border-radius: 5px;
  margin: 0px;
  padding: 10px;
  font-size: 12px;
  font-family: monospace;
}

#card {
  text-align: center;
}

::-webkit-scrollbar{
    width: 16px;
    height: 10px;
    margin-right:2px;
    border-radius:20px;


}
::-webkit-scrollbar-track{
    -webkit-box-shadow: inset 0 0 1px rgba(0,0,0,0.3);
    border: 1px solid lightblue;
    background: lightblue;
    border-radius: 30px;
    margin-right:2px;

}
::-webkit-scrollbar-thumb{
    border-radius:20px;
    height: 30px;
    width: 8px;
    border: 1px solid lightblue;
    background: rgb(111,111,111);
    background: -webkit-linear-gradient(#e66465, #9198e5);
}
::-webkit-scrollbar-track-piece {
    height: 30px;
    width: 30px;
    border-radius:20px;
}
</style>
`
export {
  mainCSS
}
