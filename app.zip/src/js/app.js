/**
 * The starting point of the application.
 *
 * @author Niklas Nilsson
 * @version 1.0
 */

import './dragable.js'
import './memory-game.js'
import './weather.js'
import './chat.js'
import './desktop.js'
